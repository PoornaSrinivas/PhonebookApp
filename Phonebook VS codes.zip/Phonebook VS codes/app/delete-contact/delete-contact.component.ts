import { Component, OnInit } from '@angular/core';
import { contact } from '../contact';
import { contactservice } from '../contactservice';


@Component({
  selector: 'app-delete-contact',
  templateUrl: './delete-contact.component.html',
  styleUrls: ['./delete-contact.component.css']
})
export class DeleteContactComponent implements OnInit {
  
  nametodelete: string;
   constructor(private service: contactservice) { }

  ngOnInit(): void {
  }
  deleteContact(nametodelete: string){
    this.service.deleteContact(this.nametodelete).subscribe(data => {
      alert(JSON.stringify(data));
      alert(data);
      console.log(data);
      
    })
  }
}
