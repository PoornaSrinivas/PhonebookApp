import { Component, OnInit } from '@angular/core';
import { contact } from '../contact';
import { contactservice } from '../contactservice';

@Component({
  selector: 'app-add-contact',
  templateUrl: './add-contact.component.html',
  styleUrls: ['./add-contact.component.css']
})
export class AddContactComponent implements OnInit {

  con : contact = new contact();

  constructor(private service: contactservice) { }

  ngOnInit(): void {
  }
  addContact() {
    //alert(JSON.stringify(this.carPart));
    this.service.addContact(this.con).subscribe(data => {
     
     // alert(JSON.stringify(data));
    })
  }
}
